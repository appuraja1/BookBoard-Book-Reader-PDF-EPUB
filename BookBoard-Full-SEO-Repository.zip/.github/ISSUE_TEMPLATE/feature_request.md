---
name: Feature request
about: Suggest an idea or feature
---

**Feature Description:**
A clear description of what feature you would like to see in BookBoard.
