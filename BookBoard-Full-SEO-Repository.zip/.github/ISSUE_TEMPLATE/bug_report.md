---
name: Bug report
about: Create a report to help us improve BookBoard
---

**Describe the bug:**
A clear description of what happened.

**Steps to Reproduce:**
1. Open file format '...'
2. Action taken '...'
3. Error observed '...'

**Device info:**
- Device model:
- Android version:
- App version:
